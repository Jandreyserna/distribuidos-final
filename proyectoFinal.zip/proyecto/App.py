from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime
import time
from pymysql import cursors
from sql.conexion import Database
import random

app= Flask(__name__)

database = Database()




#iniciamos una secction
app.secret_key = 'mysecret'

@app.route('/')
def Index():
    return render_template('index.html')

@app.route('/ciudadanos')
def Votante():
    datas = database.consult_votantes()
    return render_template('votantes.html', votantes= datas)

@app.route('/candidatos')
def candidato():
    partidos = database.consult_partidos()
    datas = database.consult_candidatos()
    return render_template('candidatos.html', candidatos= datas, partidoss =  partidos)

@app.route('/partidos')
def partido():
    datos = database.consult_partidos()
    return render_template('partidos.html', partidos= datos)

@app.route('/elecciones')
def elecion():
    datos = database.consult_elecciones()
    return render_template('elecciones.html', eleciones= datos)



 ###########################################################
 ########## Crud de CIUDADANOS
 ###########################################################

@app.route('/add_votante', methods=['POST'])
def add_votante():
    if request.method == 'POST':
        minus = "abcdefghijklmnopqrstuvwxyz"
        longitud = 8
        muestra = random.sample(minus, longitud)
        password = "".join(muestra)
        cedula = request.form['cedula']
        nombre = request.form['nombre']
        apellidos = request.form['apellidos']
        email = request.form['e-mail']
        celular = request.form['celular']
        foto = request.form['foto']
        dato = list()
        dato.append(cedula)
        dato.append(nombre)
        dato.append(apellidos)
        dato.append(email)
        dato.append(celular)
        dato.append(foto)
        dato.append(password)
        database.add_votante(dato)
        flash('contacto agregado satisfacoriamente y su contraseña es: {}'.format(password) )
        return redirect(url_for('Index'))

@app.route('/delete_votante/<string:id>')
def delete_votante(id):
    database.delete_votante(id)
    flash('el Votante Ha sido eliminado de la base de datos' )
    return redirect(url_for('Index'))

@app.route('/edit_votante/<id>')
def edit_votante(id):
    dato = database.select_user_vot(id)
    return render_template('edir_votante.html',votante = dato)

@app.route('/update_votante/<id>', methods=['POST'])
def update_votante(id):
    if request.method == 'POST':
        dato = list()
        dato.append(request.form['cedula'])
        dato.append(request.form['nombre'])
        dato.append(request.form['apellidos'])
        dato.append(request.form['e-mail'])
        dato.append(request.form['celular'])
        dato.append(request.form['foto'])
        dato.append(id)
        database.edit_votante(dato)
        flash('los datos han sido actualizados' )
        return redirect(url_for('Index'))


###############################################
########### Crud Partidos
###############################################

@app.route('/add_partido', methods=['POST'])
def add_partido():
    if request.method == 'POST':
        nit = request.form['nit']
        nombre = request.form['nombre']
        direccion = request.form['direccion']
        foto = request.form['foto']
        telefono = request.form['telefono']
        dato = list()
        dato.append(nit)
        dato.append(nombre)
        dato.append(direccion)
        dato.append(foto)
        dato.append(telefono)
        database.add_partido(dato)
        flash('Partido agregado satisfacoriamente' )
        return redirect(url_for('Index'))

@app.route('/delete_partido/<string:id>')
def delete_part(id):
    database.delete_partido(id)
    flash('el Partido Politico Ha sido eliminado de la base de datos' )
    return redirect(url_for('Index'))

@app.route('/edit_partido/<id>')
def editar_partido(id):
    dato = database.select_user_partido(id)
    return render_template('edit_partido.html',partido = dato)

@app.route('/update_partido/<id>', methods=['POST'])
def update_partido(id):
    if request.method == 'POST':
        dato = list()
        dato.append(request.form['nit'])
        dato.append(request.form['nombre'])
        dato.append(request.form['direccion'])
        dato.append(request.form['foto'])
        dato.append(request.form['telefono'])   
        dato.append(id)
        database.edit_partido(dato)
        print(dato)
        flash('los datos han sido actualizados' )
        return redirect(url_for('Index'))

###############################################
########### Crud candidatos
###############################################

@app.route('/add_candidato', methods=['POST'])
def add_candidato():
    if request.method == 'POST':
        minus = "abcdefghijklmnopqrstuvwxyz"
        longitud = 8
        muestra = random.sample(minus, longitud)
        password = "".join(muestra)
        cedula = request.form['cedula']
        nombre = request.form['nombre']
        celular = request.form['celular']
        email = request.form['e-mail']
        foto = request.form['foto']
        id = request.form['id']
        dato = list()
        dato.append(cedula)
        dato.append(nombre)
        dato.append(celular)
        dato.append(email)
        dato.append(foto)
        dato.append(password)
        dato.append(id)
        database.add_candidato(dato)
        flash('Candidato agregado satisfacoriamente y su contraseña es: {}'.format(password) )
        return redirect(url_for('Index'))

@app.route('/delete_candidato/<string:id>')
def delete_candidato(id):
    database.delete_candidato(id)
    flash('el Candidato Ha sido eliminado de la base de datos' )
    return redirect(url_for('Index'))

@app.route('/edit_candidato/<id>')
def editar_candidato(id):
    dato = database.select_user_candidato(id)
    partidos = database.consult_partidos()
    return render_template('edit_candidato.html',candidato = dato, partidoss = partidos)

@app.route('/update_candidato/<id>', methods=['POST'])
def update_candidato(id):
    if request.method == 'POST':
        dato = list()
        dato.append(request.form['cedula'])
        dato.append(request.form['nombre'])
        dato.append(request.form['celular'])
        dato.append(request.form['e-mail']) 
        dato.append(request.form['foto'])
        dato.append(request.form['id'])   
        dato.append(id)
        database.edit_candidato(dato)
        flash('los datos han sido actualizados' )
        return redirect(url_for('Index'))

###############################################
########### Crud eleciones
###############################################

@app.route('/add_eleccion', methods=['POST'])
def add_elecciones():
    if request.method == 'POST':
        fecha = request.form['fecha']
        hora1 = request.form['hora']
        hora2 = request.form['hora2']
        nombre = request.form['nombre']
        descripcion = request.form['descripcion']
        dato = list()
        dato.append(fecha)
        dato.append(hora1)
        dato.append(hora2)
        dato.append(nombre)
        dato.append(descripcion)
        fecha1 = datetime.today().strftime('%Y-%m-%d')
        fecha2 = time.strptime(fecha, "%Y-%m-%d")
        fecha1 = time.strptime(fecha1, "%Y-%m-%d")
        if fecha1 < fecha2: 
            database.add_eleccion(dato)
            flash('Elecciones agregadas satisfacoriamente' )
            return redirect(url_for('Index'))
        else:
            flash('la Fecha que entro no es valida' )
            return redirect(url_for('elecion'))

@app.route('/delete_eleccion/<string:id>')
def delete_eleccion(id):
    database.delete_eleccion(id)
    flash('El dia de elecciòn Ha sido eliminado de la base de datos' )
    return redirect(url_for('Index'))

@app.route('/edit_eleccion/<id>')
def editar_eleccion(id):
    dato = database.select_user_eleccion(id)
    return render_template('edit_eleccion.html',eleccion = dato)

@app.route('/update_eleccion/<id>', methods=['POST'])
def update_eleccion(id):
    if request.method == 'POST':
        dato = list()
        dato.append(request.form['fecha'])
        dato.append(request.form['hora'])
        dato.append(request.form['hora2'])
        dato.append(request.form['nombre']) 
        dato.append(request.form['descripcion'])  
        dato.append(id)
        database.edit_eleccion(dato)
        flash('Elecciones actualizadas satisfacoriamente' )
        return redirect(url_for('Index'))

####################################################################
# ########### registro un candidato en una elecciòn
# ##############################################################      

@app.route('/registrar_candidato/<id>')
def resgistrar_candidato_eleccion(id):
    datas = database.consult_candidatos()
    dato = database.select_user_eleccion(id)
    candidats = database.select_user_elec_candidato_table(id)
    print(candidats)
    return render_template('candidato_eleccion.html',candidatos = datas, eleccion = dato, eleccan = candidats)

@app.route('/add_eleccion_candidato', methods=['POST'])
def add_eleccion_candidato():
    if request.method == 'POST':
        ide = request.form['ideleccion']
        idc = request.form['id']
        dato = list()
        dato.append(ide)
        dato.append(idc)
        existe = database.select_user_eleccion_candidato(dato)
        if existe == "":
            flash('el Candidato ya esta registrado' )
            return redirect(url_for('Index'))       
        else:
            database.add_eleccion_candidato(dato)
            flash('Candidato agregado satisfacoriamente a la eleccion' )
            return redirect(url_for('Index'))

#############################################################################
############### Validar Votaciones
##############################################################################

@app.route('/iniciar_eleccion' , methods=['POST'])
def iniciar_eleccion():
    if request.method == 'POST':
        dato= list()
        dato.append(request.form['id'])
        dato.append(request.form['pass'])
        user=database.consult_users(dato)
        print (user)
        if user == None:
            flash('Datos incorrectos para iniciar una votacion' )
            return redirect(url_for('Index'))  
        else:
            database.update_elecciones(request.form['ideleccion'])
            flash('votacion lista para votantes' )
            return redirect(url_for('Index')) 

@app.route('/voto/<id>')
def inicio(id):
    state = database.consult_state_eleccion(id)
    if state == None:
        flash('la ELECCION aun no comienza' )
        return redirect(url_for('Index'))
    else: 
        datas = database.consult_candidatos_voto(id)
        return render_template('pre_iniciar.html',candidatos = datas, eleccion = id)

@app.route('/voto/votado' , methods=['POST'])
def votado():
    if request.method == 'POST':
        datos = list()
        datos.append(request.form['cedula'])
        datos.append(request.form['pass']) 
        ident = database.consult_ident_votante(datos)
        if ident == None:
            flash('los datos Son incorrectos, vuelva a probar' )
            return redirect(url_for('Index'))
        else:
            dates = list()
            dates.append(request.form['idcandidato'])  
            dates.append(request.form['ideleccion']) 
            database.update_candidatos_voto(dates)
            dates.append(ident[0])
            database.update_voto_eleccion(dates)
            flash('Voto registrado acertadamente' )
            return redirect(url_for('Index'))

@app.route('/voto/cerrar' , methods=['POST'])
def cerrar():
    if request.method == 'POST':
        datos = list()
        datos.append(request.form['id'])
        datos.append(request.form['pass'])
        ident = database.consult_users(datos)
        if ident == None:
            flash('los datos Son incorrectos para cerrar una Votacion' )
            return redirect(url_for('Index'))
        else:
            database.update_elecciones2(request.form['ideleccion'])
            flash('Votacion cerrada exitosamente' )
            return redirect(url_for('Index'))

if __name__ == '__main__':
    app.run(port = 8888, debug = True)


