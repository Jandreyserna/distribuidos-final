-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-12-2021 a las 10:22:33
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `elecciones`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `candidatos`
--

CREATE TABLE `candidatos` (
  `IdCandidato` int(9) NOT NULL,
  `Cedula` int(11) NOT NULL,
  `Nombre` varchar(40) COLLATE utf8_spanish2_ci NOT NULL,
  `Celular` varchar(15) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `E-mail` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Foto` varchar(60) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Password` int(11) NOT NULL,
  `IdPartido` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `candidatos`
--

INSERT INTO `candidatos` (`IdCandidato`, `Cedula`, `Nombre`, `Celular`, `E-mail`, `Foto`, `Password`, `IdPartido`) VALUES
(2, 1089065, 'juan pablo Gallo', '31134784', 'gallo@gmail.com', '', 0, 2),
(3, 101010, 'CArlos Osorio', '31436587', 'carnos@gmail.com', '', 0, 4),
(4, 108878, 'Jairo Lopez', '315346789', 'Jairo@gmail.co', '', 0, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `candidato_eleccion`
--

CREATE TABLE `candidato_eleccion` (
  `IdCandidato` int(9) NOT NULL,
  `IdEleccion` int(9) NOT NULL,
  `votos` int(9) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `candidato_eleccion`
--

INSERT INTO `candidato_eleccion` (`IdCandidato`, `IdEleccion`, `votos`) VALUES
(2, 1, 1),
(3, 1, 0),
(4, 1, 0),
(2, 1, 1),
(2, 3, 0),
(3, 3, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eleccion`
--

CREATE TABLE `eleccion` (
  `IdEleccion` int(9) NOT NULL,
  `Fecha` date NOT NULL,
  `HoraInicio` time NOT NULL,
  `HoraFinal` time NOT NULL,
  `Nombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Descripcion` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `estado` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `eleccion`
--

INSERT INTO `eleccion` (`IdEleccion`, `Fecha`, `HoraInicio`, `HoraFinal`, `Nombre`, `Descripcion`, `estado`) VALUES
(1, '2021-12-17', '18:35:00', '17:17:00', 'gubernamentales', 'se elige el gobernador de Risaralda', 2),
(3, '2021-12-19', '06:03:00', '15:03:00', 'presidenciales', 'se elige al Presidente de la República', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `partido_politico`
--

CREATE TABLE `partido_politico` (
  `IdPartido` int(9) NOT NULL,
  `Nit` int(9) NOT NULL,
  `Nombre` varchar(40) COLLATE utf8_spanish2_ci NOT NULL,
  `Direccion` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Foto` varchar(60) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Telefono` varchar(15) COLLATE utf8_spanish2_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `partido_politico`
--

INSERT INTO `partido_politico` (`IdPartido`, `Nit`, `Nombre`, `Direccion`, `Foto`, `Telefono`) VALUES
(4, 123456, 'alianza verde', 'sede pereira', 'no hay no', '3163587'),
(5, 325487, 'liberal', 'sede Dosquebradas', '', '35363938');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(9) NOT NULL,
  `username` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `pass` varchar(9) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '123'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `pass`) VALUES
(1, 'jaime gonzales', '123'),
(2, 'lucas gregorio santo', '123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `votantes`
--

CREATE TABLE `votantes` (
  `IdVotante` int(9) NOT NULL,
  `Cedula` int(11) NOT NULL,
  `Nombre` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `Apellidos` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `E-mail` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Celular` varchar(15) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Foto` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Password` varchar(15) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `votantes`
--

INSERT INTO `votantes` (`IdVotante`, `Cedula`, `Nombre`, `Apellidos`, `E-mail`, `Celular`, `Foto`, `Password`) VALUES
(2, 1088036722, 'jandrey', 'serna Restrepo', 'jandrey.serna@utp.edu.co', '3116391400', 'no hay', 'nazciflh'),
(3, 12345, 'juan', 'medina', 'medina@utp.edu.co', '333335', 'claro que no hay', 'jgyraulq'),
(4, 12345687, 'lucas', 'trejos', 'lucas@', '3233536', '', 'cwdyrzkf'),
(5, 1087035, 'maria', 'henao', 'maria@gmail.co', '315394', '', 'ivkgadrm'),
(6, 1087035744, 'Angela', 'Valencia', 'angel@utp.edu.co', '305313699', '', 'zwbcdlsf'),
(7, 10984, 'steven', 'Restrepo', 'stevenserna@gmail.co', '314151668', '', 'abhkydwx'),
(8, 2147483647, 'Juli', 'Valencia', 'Juli.v@utp.edu.co', '312356987', '', 'xhecktyl'),
(9, 1234, 'jandrey', 'restrepo', 'jandrey@utp', '769832', '', 'awqkujzp');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `voto_eleccion`
--

CREATE TABLE `voto_eleccion` (
  `IdVotante` int(9) NOT NULL,
  `IdEleccion` int(9) NOT NULL,
  `IdCandidato` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `voto_eleccion`
--

INSERT INTO `voto_eleccion` (`IdVotante`, `IdEleccion`, `IdCandidato`) VALUES
(2, 1, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `candidatos`
--
ALTER TABLE `candidatos`
  ADD PRIMARY KEY (`IdCandidato`),
  ADD UNIQUE KEY `Cedula` (`Cedula`),
  ADD KEY `relacion` (`IdPartido`);

--
-- Indices de la tabla `candidato_eleccion`
--
ALTER TABLE `candidato_eleccion`
  ADD KEY `candidato` (`IdCandidato`),
  ADD KEY `eleccion` (`IdEleccion`);

--
-- Indices de la tabla `eleccion`
--
ALTER TABLE `eleccion`
  ADD PRIMARY KEY (`IdEleccion`),
  ADD UNIQUE KEY `fecha` (`Fecha`);

--
-- Indices de la tabla `partido_politico`
--
ALTER TABLE `partido_politico`
  ADD PRIMARY KEY (`IdPartido`),
  ADD UNIQUE KEY `nit` (`Nit`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `votantes`
--
ALTER TABLE `votantes`
  ADD PRIMARY KEY (`IdVotante`),
  ADD UNIQUE KEY `cedula` (`Cedula`);

--
-- Indices de la tabla `voto_eleccion`
--
ALTER TABLE `voto_eleccion`
  ADD KEY `votante` (`IdVotante`),
  ADD KEY `eleccion` (`IdEleccion`),
  ADD KEY `candidato` (`IdCandidato`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `candidatos`
--
ALTER TABLE `candidatos`
  MODIFY `IdCandidato` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `eleccion`
--
ALTER TABLE `eleccion`
  MODIFY `IdEleccion` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `partido_politico`
--
ALTER TABLE `partido_politico`
  MODIFY `IdPartido` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `votantes`
--
ALTER TABLE `votantes`
  MODIFY `IdVotante` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
