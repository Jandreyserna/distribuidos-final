import pymysql

class Database:
    def __init__(self) -> None:
        self.connection = pymysql.connect(
            host= 'localhost',
            user= 'root',
            password='',
            db='elecciones'
        )

        self.cursor = self.connection.cursor()
        print("conexion establecida exitoxamente")
    
################################################################
############## Solicitudes para votantes
################################################################

    def select_user_vot(self, id):
        sql = 'SELECT * FROM votantes WHERE IdVotante = %s'
    

        try:
            self.cursor.execute(sql,id)
            user = self.cursor.fetchone()

            return user            
        
        except Exception as e:
            raise

    def add_votante(self, list):
        sql = "INSERT INTO votantes (`Cedula`, `Nombre`, `Apellidos`, `E-mail`, `Celular`, `Foto`, `Password`) VALUES(%s,%s,%s,%s,%s,%s,%s)"
            
        try:
            self.cursor.execute(sql,list)
            self.connection.commit()
       
        except Exception as e:
            raise
    
    def consult_votantes(self):
        sql = 'SELECT * FROM votantes WHERE 1'
    

        try:
            self.cursor.execute(sql)
            user = self.cursor.fetchall()
            return user

        except Exception as e:
            raise

    def consult_ident_votante(self,datas):
        sql = 'SELECT * FROM votantes WHERE Cedula = %s AND `Password` = %s'
    
        try:
            self.cursor.execute(sql,datas)
            user = self.cursor.fetchone()
            return user

        except Exception as e:
            raise

    def delete_votante(self, id):
        sql = 'DELETE  FROM votantes WHERE IdVotante = {}'.format(id)
    

        try:
            self.cursor.execute(sql)
            self.connection.commit()

        except Exception as e:
            raise

    def edit_votante(self, list):
        sql = 'UPDATE votantes SET `Cedula` = %s , `Nombre` = %s , `Apellidos` = %s, `E-mail` = %s, `Celular` = %s, `Foto` = %s WHERE `IdVotante` = %s '
    

        try:
            self.cursor.execute(sql, list)
            self.connection.commit()

        except Exception as e:
            raise

###############################################################################
##########Solicitudes para partidos
##############################################################################

    def select_user_partido(self, id):
        sql = 'SELECT * FROM partido_politico WHERE IdPartido = %s'
    

        try:
            self.cursor.execute(sql,id)
            user = self.cursor.fetchone()
            return user            
        
        except Exception as e:
            raise

    def add_partido(self, list):
        sql = "INSERT INTO partido_politico (`Nit`, `Nombre`, `Direccion`, `Foto`, `Telefono`) VALUES(%s,%s,%s,%s,%s)"
            
        try:
            self.cursor.execute(sql,list)
            self.connection.commit()
       
        except Exception as e:
            raise
    
    def consult_partidos(self):
        sql = 'SELECT * FROM partido_politico WHERE 1'
    

        try:
            self.cursor.execute(sql)
            user = self.cursor.fetchall()
            return user

        except Exception as e:
            raise

    def delete_partido(self, id):
        sql = 'DELETE  FROM partido_politico WHERE IdPartido = {}'.format(id)
    

        try:
            self.cursor.execute(sql)
            self.connection.commit()

        except Exception as e:
            raise

    def edit_partido(self, list):
        sql = 'UPDATE partido_politico SET `nit` = %s , `Nombre` = %s , `direccion` = %s, `foto` = %s, `telefono` = %s WHERE `IdPartido` = %s '
    

        try:
            self.cursor.execute(sql, list)
            self.connection.commit()

        except Exception as e:
            raise

###############################################################################
##########Solicitudes para candidatos
##############################################################################

    def select_user_candidato(self, id):
        sql = 'SELECT * FROM Candidatos WHERE IdCandidato = %s'
    

        try:
            self.cursor.execute(sql,id)
            user = self.cursor.fetchone()
            return user            
        
        except Exception as e:
            raise

    def add_candidato(self, list):
        sql = "INSERT INTO candidatos (`Cedula`, `Nombre`, `Celular`, `E-mail`, `Foto`, `Password`, `IdPartido`) VALUES(%s,%s,%s,%s,%s,%s,%s)"
            
        try:
            self.cursor.execute(sql,list)
            self.connection.commit()
       
        except Exception as e:
            raise
    
    def consult_candidatos(self):
        sql = 'SELECT * FROM candidatos WHERE 1'
    

        try:
            self.cursor.execute(sql)
            user = self.cursor.fetchall()
            return user

        except Exception as e:
            raise

    def delete_candidato(self, id):
        sql = 'DELETE  FROM candidatos WHERE IdCandidato = {}'.format(id)
    

        try:
            self.cursor.execute(sql)
            self.connection.commit()

        except Exception as e:
            raise

    def edit_candidato(self, list):
        sql = 'UPDATE candidatos SET `Cedula` = %s , `Nombre` = %s , `Celular` = %s, `E-mail` = %s, `foto` = %s, `IdPartido` = %s WHERE `IdCandidato` = %s '
    

        try:
            self.cursor.execute(sql, list)
            self.connection.commit()

        except Exception as e:
            raise

###############################################################################
##########Solicitudes para elecciones
##############################################################################

    def select_user_eleccion(self, id):
        sql = 'SELECT * FROM eleccion WHERE IdEleccion = %s'
    

        try:
            self.cursor.execute(sql,id)
            user = self.cursor.fetchone()
            return user            
        
        except Exception as e:
            raise

    def add_eleccion(self, list):
        sql = "INSERT INTO eleccion (`Fecha`, `HoraInicio`, `HoraFinal`, `Nombre`, `Descripcion`) VALUES(%s,%s,%s,%s,%s)"
            
        try:
            self.cursor.execute(sql,list)
            self.connection.commit()
       
        except Exception as e:
            raise
    
    def consult_elecciones(self):
        sql = 'SELECT * FROM eleccion WHERE 1'
    

        try:
            self.cursor.execute(sql)
            user = self.cursor.fetchall()
            return user

        except Exception as e:
            raise
    
    def consult_state_eleccion(self, id):
        sql = 'SELECT Nombre FROM eleccion WHERE IdEleccion = %s AND estado = 1'
    

        try:
            self.cursor.execute(sql, id)
            user = self.cursor.fetchone()
            return user

        except Exception as e:
            raise

    def delete_eleccion(self, id):
        sql = 'DELETE  FROM eleccion WHERE IdEleccion = {}'.format(id)
    

        try:
            self.cursor.execute(sql)
            self.connection.commit()

        except Exception as e:
            raise

    def edit_eleccion(self, list):
        sql = 'UPDATE eleccion SET `Fecha` = %s , `HoraInicio` = %s , `HoraFinal` = %s, `Nombre` = %s, `Descripcion` = %s WHERE `IdEleccion` = %s '
    

        try:
            self.cursor.execute(sql, list)
            self.connection.commit()

        except Exception as e:
            raise

    def update_elecciones(self, id):
        sql = 'UPDATE eleccion SET `estado` = 1  WHERE `IdEleccion` = %s '
    

        try:
            self.cursor.execute(sql, id)
            self.connection.commit()

        except Exception as e:
            raise

    def update_elecciones2(self, id):
        sql = 'UPDATE eleccion SET `estado` = 2  WHERE `IdEleccion` = %s '

        try:
            self.cursor.execute(sql, id)
            self.connection.commit()

        except Exception as e:
            raise

###############################################################################
##########Solicitudes para elecciones_candidato table
##############################################################################

    def select_user_eleccion_candidato(self, ids):
        sql = 'SELECT * FROM candidato_eleccion WHERE IdEleccion = %s AND IdCandidato = %s'
    

        try:
            self.cursor.execute(sql,ids)
            user = self.cursor.fetchone()
            return user            
        
        except Exception as e:
            raise

    def add_eleccion_candidato(self, list):
        sql = "INSERT INTO candidato_eleccion (`IdEleccion`, `IdCandidato` ) VALUES(%s,%s)"
            
        try:
            self.cursor.execute(sql,list)
            self.connection.commit()
       
        except Exception as e:
            raise

    def update_candidatos_voto(self, list):
        sql = "UPDATE candidato_eleccion SET `votos` = `votos` + 1 WHERE IdCandidato = %s AND IdEleccion = %s"
            
        try:
            self.cursor.execute(sql,list)
            self.connection.commit()
       
        except Exception as e:
            raise
    
    def select_user_elec_candidato_table(self, id):
        sql = 'SELECT * FROM `candidatos` INNER JOIN `candidato_eleccion` WHERE candidatos.IdCandidato = candidato_eleccion.IdCandidato AND candidato_eleccion.IdEleccion = %s'
    

        try:
            self.cursor.execute(sql,id)
            user = self.cursor.fetchall()
            return user            
        
        except Exception as e:
            raise

###############################################################################
##########Solicitudes para super admin 
##############################################################################

    def consult_users(self, ids):
        sql = 'SELECT users.`username` FROM `users` INNER JOIN eleccion  WHERE users.`id` = %s AND users.`pass` = %s AND eleccion.`estado` = 0'
    

        try:
            self.cursor.execute(sql,ids)
            user = self.cursor.fetchone()
            return user            
        
        except Exception as e:
            raise

###############################################################################
##########consultas de votos
##############################################################################

    def consult_candidatos_voto(self, id):
        sql = 'SELECT candidatos.`IdCandidato`, candidatos.`Nombre` FROM `candidatos` INNER JOIN candidato_eleccion  WHERE candidatos.`IdCandidato` = candidato_eleccion.`IdCandidato` AND candidato_eleccion.`IdEleccion` = %s'
    

        try:
            self.cursor.execute(sql,id)
            user = self.cursor.fetchall()
            return user            
        
        except Exception as e:
            raise

###############################################################################
##########consultas de votos_eleccion table
##############################################################################

    def update_voto_eleccion(self, list):
        sql = "INSERT INTO voto_eleccion (`IdCandidato`, `IdEleccion`, `IdVotante` ) VALUES(%s,%s,%s)"
            
        try:
            self.cursor.execute(sql,list)
            self.connection.commit()
       
        except Exception as e:
            raise